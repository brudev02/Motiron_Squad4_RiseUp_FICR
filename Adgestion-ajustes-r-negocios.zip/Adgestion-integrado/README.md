# Adgestion - Plataforma de Gestão Corporativa

> **Gestão centralize. Informações organizadas. Decisões mais eficientes.**

A **Adgestion** é uma plataforma web de gestão corporativa desenvolvida para centralizar o acompanhamento de unidades, documentos, tarefas e indicadores em um único painel.

O projeto busca simular uma aplicação SaaS voltada para diferentes empresas, aplicando boas práticas de desenvolvimento Front-End, Arquitetura de Software e Experiência do usuário(UX/IU).

---

# 🎯 Objetivos

- Centralizar informações de diferentes unidades empresarias.
- Facilitar o acompanhamento de documentos e suas respectivas validades.
- Organizar tarefas, prazos e estados de execução.
- Apresentar indicadores gerais em um dashboard.
- Garantir uma interface intuitiva, responsiva e consistente.
- Aplicar boas práticas de desenvolvimento Front-End e Arquitetura de Software.

# 👥 Público-Alvo

A plataforma foi concebida para atender **diferentes empresas**, independentemente de um segmento empresarial específico, que necessitam centralizar informações e acompanhar suas unidades, documentos e tarefas.

---

# 🧩 Funcionalidades

- **Login:** Autenticação e validação de formularios.
- **Dashboard:** Visão geral de unidades, documentos e tarefas pendentes.
- **Gestão de Unidades:** Listagem, pesquisa, filtros e detalhamento de uniades.
- **Documentos:** Acompanhamento de validade e identificação de vencimentos.
- **Tarefas:** Controle de atividades, prazos e status.
- **Indicadores Dinâmicos:** Atualização das informações realizadas no sistema.

---

# ⌨⚙️ Tecnologias

| Tecnologia |  Utilização        |
|------------|--------------------|
| Next.js  |  Desenvolvimento de aplicação web  |
| TypeScript  |  Tipagem e organização do código  |
| HTML5  |  Estrutura das páginas  |
| CSS3  |  Estelização e responsividade  |
| JavaScript | Recursos moderdos da linguagem  |

---

# 📜 Bibliotecas Utilizadas

### Usadas na Aplicação:

- Next.js, React e React DOM - **Framework e Interface.**
- Prisma, Prisma Client e @prisma/adapter-better-sqlite3 - **Banco de dados SQLite.**
- bcrypts - **Processamento seguro de senhas.**
- Jose - **Operadores de tokens.**
- Zod - **Validação de dados.**

### Desenvolvimento e estilos:

- Tailwind CSS e @tailwindcss/postcss.
- TypeScript
- ESLint e eslint-config-next

---

# 💻 Como Executar

**Pré-requisitos:** Node.js, npm e Git.

#### Clonar o repositório
> git clone https://github.com/brudev02/Motiron_Squad4_RiseUp_FICR.git

#### Acessar a pasta do projeto
> cd Motiron_Squard4_RiseUp_FICR

#### Instalar as dependências
> npm install

#### Configurar o ambiente
> copie `.env.example` para `.env` e defina `JWT_SECRET` (string aleatória com no mínimo 32 caracteres)

#### Criar o banco de dados local (SQLite)
> npm run db:push

#### Iniciar o ambiente de desenvolvimento
> npm run dev

Acesse `http://localhost:3000`, crie uma conta em **Começar agora** e entre pelo **Entrar**. O dashboard fica em `/dashboard` e só abre com sessão válida. Em **Configurações** é possível carregar (e remover) dados de exemplo.

Verificações: `npm run lint` e `npm run build`.

---

# Roadmap

As etapas abaixo representam o planejamento de evolução do projeto. O status de cada item deverá ser atualizado conforme a implementação real da equipe.

## Etapas Concluidas:

- [x] Configuração do Next.js com TypeScript
- [x] Definição do Design System
- [x] Implementação de tela de login
- [x] Implementação do Dashboard
- [x] Implementação da Aba de Tarefas
- [x] Implementação da Aba de Documentos
- [x] Desenvolvimento das listagens e dos detalhes
- [x] Implementação de recursos de acessibilidade
- [x] Implementação das avaliações de formulários
- [x] Controle de Status das unidades
- [x] Confirmação de conclusão de tarefas
- [x] Implementar cache e atualização dos dados entre telas

## Melhorias planejadas

- [ ]  Criar uma camada de API ou servidor de dados simulados
- [ ] Bloquear a exclusão de unidades com ducumentos pendentes ou tarefas em andamento
- [ ] Registrar um histórico de alterações
- [ ] Implementar modo escuro
      
---

# Status

## 🚧 Em desenvolvimento

Projeto desenvolvido com parceria da Motiron e a FICR, com foco em Arquitetura Front-End, organização de códigos, regras de negócio e boas práticas de engenharia de software.

---

## Correções de regras de negócio

Veja [CORRECOES-REGRAS-DE-NEGOCIO.md](CORRECOES-REGRAS-DE-NEGOCIO.md) para escopo, atualização do banco, limitações e roteiro de validação antes do merge.
